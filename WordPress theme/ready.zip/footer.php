<footer>
    <p>Copyright &copy; Anne Korhonen 2022 <p>
</footer>
<?php wp_footer(); ?>
</body>
</html>